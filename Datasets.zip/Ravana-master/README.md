# Ravana

 <a href="https://www.instagram.com/princekrvert/"> <img src="https://img.shields.io/badge/Instagram-E4405F?style=for-the-badge&logo=instagram&logoColor=white"></a>
<a href="https://m.twitter.com/princekrvert" > <img src="https://img.shields.io/badge/Twitter-1DA1F2?style=for-the-badge&logo=twitter&logoColor=white"> </a>
<a href="https://www.youtube.com/channel/UCiplAqC9AwtGGxXU3WQy8pw"><img src="https://img.shields.io/badge/YouTube-FF0000?style=for-the-badge&logo=youtube&logoColor=white"></a>
<a href="https://www.facebook.com/princekrvert" > <img src="https://img.shields.io/badge/Facebook-1877F2?style=for-the-badge&logo=facebook&logoColor=white" ></a>

 ![20220923_091331](https://user-images.githubusercontent.com/56459297/191888843-62b199ec-6c1e-4b7d-b268-41b244d5bcee.png)

```
  cloudflare link forwoding 
```
 
*`git clone https://github.com/princekrvert/Ravana.git`
 
 
*`cd Ravana`
 
 *`chmod +x ravana.sh`
 
*`./ravana.sh`
 
## WARNING :-THIS TOOL IS MADE ONLY FOR EDUCATIONAL PURPOSES

### English pdf Download here--
[PDF](http://www.mediafire.com/file/rgoq0g9yjwytm42/Ravana.docx/file)

[Ravana 2.5](https://is.gd/ZfEPvA)

